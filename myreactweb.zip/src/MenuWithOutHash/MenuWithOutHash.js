import React    from "react";
import template from "./MenuWithOutHash.jsx";

class MenuWithOutHash extends React.Component {
  render() {
    return template.call(this);
  }
}

export default MenuWithOutHash;
