import HOC from "./HOC";
export default HOC;
