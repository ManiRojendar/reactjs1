import "./HOC.css";
import React from "react";
import Click from '../myHoc/Click/index';
import Hover from '../myHoc/Hover/index';
function template() {
  return (
    <div className="hoc">
      <h1>HOC</h1>
      <Click />
      <Hover />
    </div>
  );
};

export default template;
