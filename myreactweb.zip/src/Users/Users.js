import React from "react";
import template from "./Users.jsx";
import ServerCall from '../services/ServerCall';
class Users extends React.Component {
  constructor() {
    super();
    this.state = {
      'dataObj': {
        name: '',
        rno: '',
        email: '',
        loc: ''
      },
      'msg': '',
      'headers': ['ID', 'STD NAME', 'STD RNO', 'EMAIL', 'LOC'],
      'keys': ['id', 'name', 'rno', 'email', 'loc'],
      'data': [],
      'isUpdate': false
    }
    this.fnPrepareData = this.fnPrepareData.bind(this);
    this.fnGetStudetns = this.fnGetStudetns.bind(this);
    this.fnEditData = this.fnEditData.bind(this);
    this.fnGetStudetns();
  }
  render() {
    return template.call(this);
  }

  fnPrepareData(key, value) {
    this.setState({
      dataObj: {
        ...this.state.dataObj,
        [key]: value
      }
    })
  }

  fnGetStudetns() {
    debugger;
    ServerCall.fnGetReq('http://localhost:2020/users/std-list')
      .then(
        (res) => {
          this.setState({
            data: res.data
          })
        }
      )
      .catch((res) => {
        this.setState({
          data: []
        })
      })
  }
  fnEditData(userData) {
    this.setState({
      dataObj: userData,
      isUpdate: true
    })
  }

  fnUpdate() {
    ServerCall.fnPostReq('http://localhost:2020/users/update-std', this.state.dataObj)
      .then((res) => {
        if (res.data && res.data.affectedRows) {
          this.fnGetStudetns();
          this.setState({
            'msg': 'success',
            isUpdate:false,
            'dataObj': {
              name: '',
              rno: '',
              email: '',
              loc: ''
            }
          })
        } else {
          this.setState({
            'msg': 'fail'
          })
        }
      })
      .catch(() => {

      })
  }

  fnDelete(id) {
    debugger;
    ServerCall.fnGetReq(
      'http://localhost:2020/users/delete-std?id='+id
    )
    .then((res)=>{
      if (res.data && res.data.affectedRows) {
        this.fnGetStudetns();
        this.setState({
          'msg': 'success',
        })
      } else {
        this.setState({
          'msg': 'fail'
        })
      }
    })
    .catch((res)=>{
      
    })
  }

  fnReg() {
    ServerCall.fnPostReq('http://localhost:2020/users/std-reg', this.state.dataObj)
      .then(
        (res) => {
          debugger;
          if (res.data && res.data.affectedRows) {
            this.fnGetStudetns();
            this.setState({
              'msg': 'success',
              'dataObj': {
                name: '',
                rno: '',
                email: '',
                loc: ''
              }
            })
          } else {
            this.setState({
              'msg': 'fail'
            })
          }
        }
      )
      .catch(() => {
        debugger;
      })
  }
}

export default Users;
