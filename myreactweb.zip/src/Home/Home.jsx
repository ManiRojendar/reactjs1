import "./Home.css";
import React from "react";

function template() {
  return (
    <div className="home">
      <h1>State value demp</h1>
      <h3>{this.state.n}</h3>
      <input type='button' value='update' onClick={this.fnUpdateState.bind(this)} />
    </div>
  );
};

export default template;
