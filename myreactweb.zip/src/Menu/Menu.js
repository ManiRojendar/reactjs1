import React    from "react";
import template from "./Menu.jsx";

class Menu extends React.Component {
  render() {
    return template.call(this);
  }
}

export default Menu;
