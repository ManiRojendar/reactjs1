import React    from "react";
import template from "./Add.jsx";

class Add extends React.Component {
  render() {
    return template.call(this);
  }
}

export default Add;
