import "./Add.css";
import React from "react";

function template() {
  return (
    <div className="add">
      <h1>Add</h1>
    </div>
  );
};

export default template;
