import React    from "react";
import template from "./About.jsx";

class About extends React.Component {
  constructor(){
    super();
    
  }
  render() {
    return template.call(this);
  }
}

export default About;
