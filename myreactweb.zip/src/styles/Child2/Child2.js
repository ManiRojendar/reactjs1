import React    from "react";
import template from "./Child2.jsx";

class Child2 extends React.Component {
  render() {
    return template.call(this);
  }
}

export default Child2;
