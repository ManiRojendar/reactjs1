import "./Child2.css";
import React from "react";
import styles from '../myStyles.module.css';
function template() {
  return (
    <div className="child-2">
      <h1 className='fs'>Child2</h1>
      <h1 className={styles.textFontStyle}>Dhonie</h1>
    </div>
  );
};

export default template;
