import "./Child1.css";
import React from "react";
import '../myStyles.css';
import Child2 from '../Child2/index';
import styles from '../myStyles.module.css';
function template() {
  const clr=this.props.d =='true' ? 'cr': 'cb'
  return (
    <div className="child-1">
      <h1 style={this.myInline}>Child1 Inline :Sachin</h1>
      <h1 className={`${clr} fs`} >Child1 extenal :Sachin</h1>
      <h1 className={styles.textFontStyle}>Child1 module :Sachin</h1>
      <Child2  />
    </div>
  );
};

export default template;
