import React    from "react";
import template from "./Mask.jsx";

class Mask extends React.Component {
  render() {
    return template.call(this);
  }
  fnConfirm(msg){
    this.props.fnConfirm(msg);
  }
}

export default Mask;
