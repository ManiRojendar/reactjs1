import React    from "react";
import template from "./MyStyles.jsx";

class MyStyles extends React.Component {
  render() {
    return template.call(this);
  }
}

export default MyStyles;
