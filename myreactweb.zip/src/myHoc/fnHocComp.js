import React from 'react';

const fnHocComp=(Original)=>{
    
    class NewComp extends React.Component{
        constructor(){
            super();
            this.state={
                count:1
            }
            this.fnIncCount=this.fnIncCount.bind(this);
        }
        fnIncCount(){
            this.setState({
                count:this.state.count+1
            })
        }
        render(){
            return <Original count={this.state.count} fnIncCount={this.fnIncCount} />
        }
    }

    return NewComp;

}

export default fnHocComp;