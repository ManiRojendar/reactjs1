import React    from "react";
import template from "./Hover.jsx";
import fnHocComp from '../fnHocComp';
class Hover extends React.Component {
  
  render() {
    return template.call(this);
  }
  
}

export default fnHocComp(Hover);
