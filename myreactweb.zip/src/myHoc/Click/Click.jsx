import "./Click.css";
import React from "react";

function template() {
  const {count,fnIncCount}= this.props;
  return (
    <div className="click">
       <button onClick={fnIncCount}>clicked me {count} time(s)</button>
    </div>
  );
};

export default template;
