import Click from "./Click";
export default Click;
