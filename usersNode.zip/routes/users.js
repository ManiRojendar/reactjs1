var express=require('express');
var router=express.Router();
var sharedObj=require('./shared');

router.post('/std-reg',function(req,res){
     var name=req.body.name;
     var rno=req.body.rno;
     var email=req.body.email;
     var loc=req.body.loc;


     sharedObj.getMysqlCon(
        res,
        function(con){
           var q="insert into users(name,rno,email,loc) values('"+name+"','"+rno+"','"+email+"','"+loc+"')";
           con.query(q,function(e,s){
            if(e){
              res.send(e);
            }else{
              res.send(s);
            }
           })
        }
     )
})

router.get('/std-list',function(req,res,next){
    sharedObj.getMysqlCon(
      res,
      function(con){
           var q="select * from users";
           con.query(q,function(e,s){
               if(e){
                 res.send(e);
               }else{
                 res.send(s);
               }
           })
      }
    )
})

router.post('/update-std',function(req,res){
  var name=req.body.name;
  var rno=req.body.rno;
  var email=req.body.email;
  var loc=req.body.loc;
  var id=req.body.id;
  sharedObj.getMysqlCon(
    res,
    function(con){
      var q="update users set name='"+name+"',rno='"+rno+"',email='"+email+"',loc='"+loc+"' where id="+id;
      con.query(q,function(e,s){
        if(e){
          res.send(e);
        }else{
          res.send(s);
        }
      })
    }
  )
})

router.get('/delete-std',function(req,res){
   var id=req.query.id;
   sharedObj.getMysqlCon(
     res,
     function(con){
         var q="delete from users where id="+id;
         con.query(q,function(e,s){
           if(e){
             res.send(e);
           }else{
             res.send(s);
           }
         })
     }
   )
})




module.exports=router;